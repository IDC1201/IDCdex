# dex-demo-embedded-openapi

This repository contains the OpenAPI specification for the DeX Demo embedded REST server.

The `release` branch is deployed automatically to Netlify. To view the API,
visit https://docs.serverfuse.tools/dex-demo-embedded. Note that updating the release branch
should be done by running the `build.sh` script in the root of the repository.

This repository may be renamed in the future in order to host additional OpenAPI docs at the same domain.