package auth

const (
	sessionName = "uex_session"
	AccountName = "dex-demo"
)
