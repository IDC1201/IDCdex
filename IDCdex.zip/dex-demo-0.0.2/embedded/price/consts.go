package price

const (
	EntityName = "price"
)
